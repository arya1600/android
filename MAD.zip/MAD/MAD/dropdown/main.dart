import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: const MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var countries=["India","china","SriLanka","USA","England"];
  String dropdownVal="India";
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: Text("Drop Down Button"),
            backgroundColor: Colors.black12,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20)
            ),
          ),
          drawer: Drawer(
            backgroundColor: Colors.black12,
          ),
          body: Center(
            child: Column(
              children: [
                SizedBox(height: 350,),
                Container(
                  child: DropdownButton(
                    value: dropdownVal,
                    items: countries.map((String country) {
                      return DropdownMenuItem(
                        value: country,
                        child: Text(country),
                      );
                    }).toList(),
                    onChanged: (String? newVal) {
                      print(newVal);
                      setState(() {
                        if(newVal!=null){
                          dropdownVal=newVal;
                          print(dropdownVal);
                        }
                      });
                    },
                  ),
                ),

                ElevatedButton(onPressed: (){
                  showDialog(context: (context), builder:(BuildContext context){
                    return AlertDialog(
                      title: Text("Submitted Successfully!"),
                      actions: [
                        TextButton(onPressed: (){
                          Navigator.of(context).pop();
                        }, child: Text("OK"))
                      ],
                    );
                  });
                }, child: Text("Submit."))
              ],
            ),
          ),
        )
    );
  }
}

