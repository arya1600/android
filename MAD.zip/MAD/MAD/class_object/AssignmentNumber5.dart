import 'dart:io';

//Que1)Write a dart program to create a class Laptop with properties [id, name, ram] and create 3 objects of it and print all details.
class laptop{
  int? id;//? or also we use late comman
  String? name;
  int? ram;
  laptop(this.id,this.name,this.ram);
  void display(){
    print("ID of the Laptop is:$id");
    print("Name of the Laptop is:$name");
    print("Size of RAM is:$ram GB");
  }
}
//Que2)Write a dart program to create a class House with properties [id, name, prize].
// Create a constructor of it and create 3 objects of it. Add them to the list and print all details.
class house{
  int? id;
  String? name;
  int? prize;
  house(this.name,this.id,this.prize);
}
//Que3)Write a dart program to create a class Animal with properties [id, name, color]. Create another class called Cat and extends it from Animal. Add
// new properties sound in String. Create an object of a Cat and print all details.
class animal{
  int? id;
  String? name;
  String? color;
  animal(this.id,this.name,this.color);
}
class cat extends animal{
  String? sound;
  cat(this.sound) : super(1,"cat","white");
}
//Que4)Write a dart program to create a class Camera with private properties [id, brand, color, prize].
// Create a getter and setter to get and set values. Also, create 3 objects of it and print all details.
class camera{
  int _id;
  String _brand;
  String _color;
  int _prize;
  camera(this._id,this._brand,this._color,this._prize);
  int get id => _id;
  String get brand => _brand;
  String get color => _color;
  int get prize => _prize;
  void setter(int id,String brand,String color,int prize){
    _id = id;
    _brand = brand;
    _color = color;
    _prize = prize;
  }
 }

 //Que5)Create an interface called Bottle and add a method to it called open().Create a class called CokeBottle and implement the Bottle and print the message “Coke bottle
// is opened”.Add a factory constructor to Bottle and return the object of CokeBottle. Instantiate CokeBottle using the factory constructor and call the open() on the object.
abstract class Bottle{
  //Method open()
  void open();
}
class CokeBottle implements Bottle{
  @override
  void open() {
    print("Coke Bottle is open");
  }
  CokeBottle._();//private constructor
  factory CokeBottle(){
    return CokeBottle._();//factory constructor return
  }
}
int main(){

  //Que1)
  print("Que1:");
  laptop l1 = laptop(1, "dell",16);
  laptop l2 = laptop(2,"lenovo",8);
  laptop l3 = laptop(3,"mac",16);
  l1.display();
  l2.display();
  l3.display();
  
  //Que2)
  print("\nQue2:");
  house h1 = house("house1",1,100000);
  house h2 = house("house2",2,200000);
  house h3 = house("house3",3,300000);

  List<house> houselist =[h1,h2,h3];

  for (var house in houselist) {
    print('House ID: ${house.id}, Name: ${house.name}, Prize: \$${house.prize}');
  }
  
  //Que3
  print("\nQue3:");
  cat c =cat("meows");
  print("ID:${c.id}\nName:${c.name}\nColor:${c.color}\nSound:${c.sound}");

  //Que4
  print("\nQue4:");
  camera c1 = camera(1, "DSLR", "White", 100000);
  camera c2 = camera(2, "DSLR", "Black", 200000);
  camera c3 = camera(3, "DSLR", "Orange", 300000);
  //c.setter(12, "DSLR", "White", 100000);
  List<camera> cameralist=[c1,c2,c3];
  for(var camera in cameralist) {
    print("ID:${camera.id}\nBrand:${camera.brand}\nColor:${camera.color}\nPrize:${camera.prize}");
  }

  //Que5
  print("\nQue5:");
  var cokeBottle = CokeBottle();
  cokeBottle.open();
  return 0;
}