import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String textFieldValue = '';

  // Function to clear the TextField
  void clearTextField() {
    setState(() {
      textFieldValue = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TextField Properties Test',
      home: Scaffold(
        appBar: AppBar(
          title: Text('TextField Properties Test'),
        ),
        body: SingleChildScrollView( // Allow scrolling for long content
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              // TextField with Decoration
              TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  labelText: 'Label Text',
                  hintText: 'Enter some text',
                  suffixIcon: Icon(Icons.check_circle),
                  prefixIcon: Icon(Icons.search),
                  helperText: 'Helper text for guidance',
                  helperStyle: TextStyle(color: Colors.grey),
                ),
                onChanged: (value) => setState(() => textFieldValue = value),
              ),
              SizedBox(height: 20.0),

              // TextField with different border styles
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  OutlinedButton(
                    onPressed: () {},
                    child: Text('Outlined'),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text('Text'),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.add),
                  ),
                ],
              ),
              SizedBox(height: 20.0),

              // TextField with resizing
              TextField(
                maxLines: null, // Allows for multi-line input
                decoration: InputDecoration(
                  hintText: 'Enter a long text',
                ),
                onChanged: (value) => setState(() => textFieldValue = value),
              ),
              SizedBox(height: 20.0),

              // Display entered text
              Text(
                'Entered Text: $textFieldValue',
                style: TextStyle(fontSize: 16.0),
              ),
              SizedBox(height: 20.0),

              // Clear button
              ElevatedButton(
                onPressed: clearTextField,
                child: Text('Clear TextField'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
