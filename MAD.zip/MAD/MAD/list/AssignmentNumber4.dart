import 'dart:io';

int main(){
  // //Que1)Create a list of names and print all names using list
  // print("\nQue1:");
  // List<String> namelist = ["pranav","prakash","sankpal"];//List<> are used to create list of the name store in []
  // for(String n in namelist) {
  //   print("$n");
  // }
  // //Que2)Create a set of fruits and print all fruits using loop.
  // print("\nQue2:");
  // Set<String>fruitlist = {"orange","Mango","Apple","Kiwi","Guava"};//Set<> are used to create set of fruit and store in {}
  // for(String fruit in fruitlist){
  //   print("$fruit");
  // }
  // //Que3)Create an empty list of type string called days. Use the add method to add names of 7 days and print all days.
  // print("\nQue3:");
  // List<String>daylist = [];
  // daylist.add("Monday");
  // daylist.add('Tuesday');
  // daylist.add('Wednesday');
  // daylist.add('Thursday');
  // daylist.add('Friday');
  // daylist.add('Saturday');
  // daylist.add('Sunday');
  // for(String day in daylist){
  // print("$day");
  // }

  // //Que4)Add your 7 friend names to the list. Use where to find a name that starts with alphabet a.
  // List<String>friend = [];
  // friend.addAll(["Pranav","abcd","b","c","d","e","f","g"]);
  // String friendstarwitha = friend.where((name) =>name.toLowerCase().startsWith('a')).first;
  // for(String friends in friend){
  //   print("$friends");
  // }
  // print("Friends name started with a:$friendstarwitha");

  // //Que5)Create a map with name, address, age, country keys and store values to it. Update country name to other country and print all keys and values.
  // Map<String,dynamic>UserDetails ={
  //   'name':'pranav',
  //   'address':'kolhapur',
  //   'age':21,
  //   'country':'india'
  // };
  // print("$UserDetails");
  // UserDetails.forEach((key, value) {print("$key:$value");});
  // UserDetails['country']='Bharat';
  // print("\n$UserDetails");

  // //Que6)Create a map with name, phone keys and store some values to it. Use where to find all keys that have length 4.
  // Map<String , dynamic>detail = {'pranav':9834096288,'abcd':123456,'bcde':1234567,'cdef':12345678,'absc':123456789};
  // Iterable<String>lengthfour = detail.keys.where((key) => key.length == 4);
  // print("Detail info:$detail");
  // print("Detail of length four:$lengthfour");

  //Que7)Create a simple to-do application that allows user to add, remove, and view their task.
  List<String>tasks=["task"];
  int choice = 1;
  while(choice!=0) {
    print("1)Add Task\n2)Remove Task\n3)View Task\n Enter 0 to exit");
    stdout.write("Enter the choice:");
    int? choice = int.parse(stdin.readLineSync()!);
    switch (choice) {
      case 1:
        stdout.write("Enter the Task for add:");
        String? task = stdin.readLineSync()!;
        tasks.add(task);
        print("Task $task are added sucessfully !");
        break;
      case 2:
        if (tasks.isEmpty) {
          print("No any task to remove.`");
        } else {
          print("Current task:");
          for (int i = 0; i < tasks.length; i++) {
            print('${i + 1}. ${tasks[i]}');
          }
        }
        stdout.write("Enter the Index number which you have remove it:");
        int? index=int.parse(stdin.readLineSync()!);
        tasks.removeAt(index-1);
        print("$tasks");
        break;
      case 3:
        print("View task:$tasks");
        break;
    }
  }
    return 0;
  }

