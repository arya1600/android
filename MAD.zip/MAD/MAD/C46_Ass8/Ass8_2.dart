import 'package:flutter/material.dart';

class watchApp extends StatefulWidget {
  const watchApp({super.key});


  @override
  State<watchApp> createState() => _watchAppState();
}

class _watchAppState extends State<watchApp> {
  int _selectedIndex=0;

  @override
  Widget build(BuildContext context) {
    double ht=MediaQuery.of(context).size.height;
    double wd=MediaQuery.of(context).size.width;
    return Scaffold(
      body:
      Column(
        children: [
          Container(
            color: Colors.grey[900],
            height: ht*0.55,


            child: Expanded(
              child: Column(
                children: [
                  Expanded(child:
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 15.0),
                        child: Expanded(
                          child: Container(

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(20.0),
                                      child: CircleAvatar(
                                        radius: 30,
                                        backgroundImage: AssetImage("lib/images/boy.jpg"),
                                      ),

                                    ),
                                  ],

                                ),
                                Expanded(
                                  child: Column(
                                    //    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [

                                      Padding(
                                        padding: const EdgeInsets.only(top: 20),
                                        child: Text("Hello",style: TextStyle(fontSize: 20,color: Colors.blueGrey[400]),),
                                      ),
                                      Text("Abhi Shetti",style: TextStyle(fontSize: 20,color: Colors.black),),

                                      // Padding(
                                      //   padding: const EdgeInsets.only(top: 40),
                                      //   child: Image.asset("lib/images/goa2.jpg"),
                                      // ),

                                    ],


                                  ),
                                ),
                              ],
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20), // Rounded corners with a radius of 50
                            ),


                            height:100 ,
                            width: 400,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0,top: 15),
                        child: Expanded(
                          child: Container(

                            decoration: BoxDecoration(

                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20), // Rounded corners with a radius of 50
                            ),
                            child: Icon(Icons.add_alert_sharp,size: 30,),
                            height:100 ,
                            width: 80,
                          ),
                        ),
                      ),
                    ],
                  ),
                  ),
                  Expanded(
                    child: Container(
                      child:Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Image.asset("lib/images/watch.png",height: 500,width: 400,),
                      ),

                    ),
                  ),

                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10),

            child: Container(


              color: Colors.white,

              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,


                // Set spacing between columns to 0


                children: [
                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.earbuds_battery),

                          ),
                        ),
                        Text("Battery"),

                      ],
                    ),
                  ),

                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.camera_alt_outlined),

                          ),
                        ),
                        Text("Camera"),

                      ],
                    ),
                  ),
                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.perm_media),

                          ),
                        ),
                        Text("Media"),

                      ],
                    ),
                  ),

                ],
              ),

            ),
          ),


          Padding(
            padding: const EdgeInsets.only(top: 10),

            child: Container(




              child: Row(

                mainAxisAlignment: MainAxisAlignment.center,

                // Set spacing between columns to 0


                children: [
                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.bluetooth_audio),

                          ),
                        ),
                        Text("Bluetooth"),

                      ],
                    ),
                  ),

                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.wifi),

                          ),
                        ),
                        Text("Wifi"),

                      ],
                    ),
                  ),
                  // Your circular container
                  Container(

                    child: Column(


                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            radius: 30,
                            child: Icon(Icons.call),

                          ),
                        ),
                        Text("Call"),

                      ],
                    ),
                  ),

                ],
              ),

            ),
          ),
        ],
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home),label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.photo),label: "Gallery"),
          BottomNavigationBarItem(icon: Icon(Icons.more),label: "More"),
        ],
      ),


    );
  }
}
