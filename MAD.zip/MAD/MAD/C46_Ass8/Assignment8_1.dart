import 'dart:js';

import 'package:flutter/material.dart';

class AssApp1 extends StatelessWidget {
  const AssApp1({super.key});

  @override
  Widget build(BuildContext context) {

    double ht=MediaQuery.of(context).size.height;
    double wd=MediaQuery.of(context).size.width;

    return Scaffold(
      body: Column(
        children: [
          Container(
            height: ht*0.5,
            decoration: BoxDecoration(
              color: Colors.deepOrange,
            ),

            child: Container(
              decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.only(bottomRight: Radius.circular(140))
              ),
              child: Center(
                child: Padding(
                  padding: EdgeInsets.all(32.0),
                  child: Image.asset("lib/images/BGMI.png"),
                ),
              ),
            ),

          ),
          Container(
            height: ht*0.5,
            decoration: BoxDecoration(
              color: Colors.black,
            ),

            child: Container(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(140))
              ),

              child: Center(
                child: Column(
                  children: [

                    Center(
                      child: Container(
                          child:
                          Padding(
                            padding: EdgeInsets.only(top: 70),
                            child: Text(
                              "BattleGround",
                              style: TextStyle(
                                  fontSize: 50,
                                  fontWeight: FontWeight.w900
                              ),
                            ),
                          ),
                      ),
                    ),

                    Center(
                      child: Container(
                        child:
                        Padding(
                          padding: EdgeInsets.zero,
                          child: Text(
                            " Mobile India",
                            style: TextStyle(
                                fontSize: 35,
                                fontWeight: FontWeight.w300
                            ),
                          ),
                        ),
                      ),
                    ),


                    Center(
                      child: Container(
                        child:
                        Padding(
                          padding: EdgeInsets.only(top: 25),
                          child: Text(
                            "Enjoy the Gaming Experience",
                            style: TextStyle(
                                fontSize: 20,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ),
                    ),

                    Center(
                      child:Container(
                        margin: EdgeInsets.only(
                          top: 10,
                        ),
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text("Get Started",
                          style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.black,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),


                  ],
                ),
              ),


            ),
          ),

        ],
      ),
    );
  }
}
