//Que1)Create a class Person with four properties: name, phone, isMarried,and age. The class also has a method called displayInfo, which prints out the
// values of the four properties.
//import 'package:flutter/cupertino.dart';

class Person{
  String name;
  int phone;
  bool isMarried;
  int age;

  Person(this.name,this.phone,this.age,this.isMarried);//create a constructor

  void displayinfo(){//use display info method
    print("Name : $name");
    print("Phone Number : $phone");
    print("Person is married : ${isMarried ? 'Married ': 'Single'}");
    print("Age of the person : $age");
  }
}

//Que2)Create a class Car with three properties: name, color, and numberOfSeats.The class also has a method called start, which prints out the message “Car
// Started”. We also have an object of the class Car called car.(create two objects for class Car) .
class Car{
  String name;
  String color;
  int numberofSeats;
  Car(this.name,this.color,this.numberofSeats);

  void start(){
    print("$name Car Started.");
  }
}
//Que3)create a class named Employee. The class has one private property _name. We will also create a public method getName() to access the private property.
class Employee{
  late String _name;

 // Employee(this._name);
  String getName(){
    print("Name of the Employee:$_name");
    return _name;
    // print("Name of the Employee$_name");
  }
  void setName(String name){
    _name = name;
  }
}
//Que4)Try to create a class Person with two properties: name, and planet. Create a  default constructor to initialize the values of the planet to earth. Create an
// object of the class Person, set the name to “Your Name” and print the name and planet.
class person{
  String name ;
  String planet;
  person(this.name) : planet = "earth";
}

//Que5)Create a class Customer with three properties: name, age, and phone.The class should have one constant constructor. The constructor should initialize
// the values of the three properties.Create an object of the class Customer and print the values of the three properties.
class Customer{
  final String name;
  final int age;
  final int phone;
  const Customer(this.name,this.age,this.phone);//Constant constructor
}

//Que6)Create parent class Car and child class Toyota. The Toyota class inherits the properties and methods of the Car class.
class car{
  String name;
  int seat;
  car(this.name,this.seat);
  void carstart(){
    print("Car is started");
  }
  void stopcar(){
    print("Car is stoped.");
  }
}
class Toyota extends car{
  Toyota(int seat ,String name) : super (name,seat);
}

//Que7)Create a class named NoteBook. The class has two private properties _name and _prize. There are two getters name and prize to access
// the value of the properties.
class Notebook{
  String _name;
  int _prize;
  String get name=>  _name;
  int get prize => _prize;
  Notebook(this._name,this._prize);
}

//Que8)Create a class named BankAccount with one private property _balance . There is one getter balance to read the value of the property. There are
// methods deposit and withdraw to update the value of the _balance.
class BankAccount{
  double _balance;
  double get balance => _balance;//getter for the balance property
  BankAccount(double newbalance) : _balance = newbalance;//constructor
  void deposit(double amount){
    _balance += amount;
  }
  void withdraw(double amount){
    if(_balance >= amount){
      _balance -= amount;
    }else{
      print("Not sufficiant Balance.");
    }
  }
}
int main()
{
  // //Que1
  Person p = Person("Pranav",9834096288,21,false);//assign the value to the Person class
  //p.name = "pranav";p.age=21;p.isMarried=false;p.phone=21133344;
  p.displayinfo();//call display info method

  //Que2
  Car car = Car("BMW","White",5);
  Car car1 = Car("Audi","Black",7);
  car.start();
  car1.start();

  //Que3
  Employee emp = Employee();
  emp.setName("pranav");
  emp.getName();

  // //Que4
  person P = person("Pranav");
  print("Your Name : ${P.name} ");
  print("Your Planet is : ${P.planet}");

  // //Que5
  Customer C = Customer("Pranav", 21, 1234567890);
  print("Name of Customer:${C.name} \n""Age of the Customer:${C.age}\n""Phone Number of Customer:${C.phone}");

  //Que6
  Toyota t1 = Toyota(7, "Tata");
  print("Number of seats:${t1.seat} \nName of company:${t1.name}");
  t1.carstart();
  t1.stopcar();

  //Que7
  Notebook nb = Notebook("BHAGAVTGEETA",10000);
  print("Name of the book is:${nb._name} \nPrize of the book is :${nb.prize}");

  //Que8
  BankAccount bankaccount = BankAccount(1000.0);
  bankaccount.deposit(100.100);
  print("After the Deposit the money:${bankaccount._balance} ");
  bankaccount.withdraw(100.000);
  print("After the Withdraw the money:${bankaccount._balance}");
  bankaccount.withdraw(1000.00);
  print("After withdraw the money:${bankaccount._balance}");
  return 0;
}