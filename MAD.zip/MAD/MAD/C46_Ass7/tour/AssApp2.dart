import 'package:flutter/material.dart';


class AssApp2 extends StatelessWidget {
  const AssApp2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        toolbarHeight: 150,
        backgroundColor: Colors.black,
        title: Stack(
          children: [
            Container(
              child: Padding(
                padding: EdgeInsets.only(left: 10),
                child: Image.asset("lib/images/logo.jpeg",
                  width: 120,
                  height: 120,),
              ),
            ),
            Container(

              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Center(
                  child: Text(
                    'INDIA TOURS AND TRAVELS',
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

            ),
          ],
        ),
      ),


      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          Expanded(
            child: ListView(
              children: [

                Padding(
                  padding: EdgeInsets.all(2.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,

                          child: Center(
                            child: Text(
                              "India's Famous Spiritual places tour",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "India Tour",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "Kedarnath trek",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "Ayodhya Tour",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "Kashi Visit",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "Mahakal Darshan",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Container(
                          height: 80,
                          width: 760,
                          color: Colors.deepOrange,
                          child: Center(
                            child: Text(
                              "Shree Krishna Darshan",
                              style: TextStyle(
                                  color: Colors.white,fontSize: 25
                              ),
                            ),
                          ),
                        ),
                      ),

                    ],
                  ),
                ),

              ],
            ),
          ),

          Expanded(child: Container(
            child: Column(
              children: [
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Container(
                    width: 750,
                    color: Colors.cyan,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Kedarnath",style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),),
                        Expanded(
                          child: Image.asset("lib/images/Kedarnath.jpeg",width: 800,fit: BoxFit.fitWidth,
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
                ),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Container(
                    width: 750,
                    color: Colors.cyan,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("vrindavan",style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),),
                        Expanded(
                          child: Image.asset("lib/images/vrindavan.jpeg",width: 800,fit: BoxFit.fitWidth,
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
                ),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Container(
                    width: 750,
                    color: Colors.cyan,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Ujjain",style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),),
                        Expanded(
                          child: Image.asset("lib/images/Ujjain.jpg",width: 800,fit: BoxFit.fitWidth,
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
                ),
              ],
            ),
          ),
          ),
        ],
      ),
    );
  }
}
