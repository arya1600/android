import 'package:flutter/material.dart';

class AssApp1 extends StatelessWidget {
  const AssApp1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
          padding: const EdgeInsets.fromLTRB(150,100,150,100),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black,width: 3),
              color: Colors.grey[300],
            ),
            child: Row(

              mainAxisAlignment: MainAxisAlignment.center,

              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      // crossAxisAlignment: CrossAxisAlignment.center,

                      children: [
                        Padding(padding: EdgeInsets.all(20),
                          child: CircleAvatar(radius: 50,
                            backgroundColor: Colors.purple,
                          ),
                        ),

                        Column(
                          children: [
                            Text("Your Name",style: TextStyle(fontSize: 30,color: Colors.black,fontWeight: FontWeight.w400),),
                            Text("Designation",style: TextStyle(fontSize: 30,color: Colors.black,fontWeight: FontWeight.w400),),
                          ],
                        )
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Center(
                          child: Row(
                            children: [
                              Padding(padding: EdgeInsets.only(left: 20),
                                child: Icon(Icons.computer,size: 40,color: Colors.red,),
                              ),
                              SizedBox(width: 20),
                              Text('School Name,City',style: TextStyle(fontSize: 20),),
                            ],
                          ),
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Center(
                          child: Row(
                            children: [
                              Padding(padding: EdgeInsets.only(left: 20),
                                  child: Icon(Icons.folder_open,size: 40,color: Colors.amber)
                              ),
                              SizedBox(width: 20),
                              Text('Any Project',style: TextStyle(fontSize: 20),),
                            ],
                          ),
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Center(
                          child: Row(
                            children: [
                              Padding(padding: EdgeInsets.only(left: 20),
                                child: Icon(Icons.email,size: 40,color: Colors.blue,),
                              ),
                              SizedBox(width: 20),
                              Text('Email',style: TextStyle(fontSize: 20),),
                            ],
                          ),
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Center(
                          child: Row(
                            children: [
                              Padding(padding: EdgeInsets.only(left: 20),
                                child: Icon(Icons.call,size: 40,color: Colors.green,),
                              ),
                              SizedBox(width: 20),
                              Text('Mobile Number',style: TextStyle(fontSize: 20),),
                            ],
                          ),
                        ),
                      ],
                    ),

                  ],
                )
              ],
            ),
          ),
        )
    );
  }
}
