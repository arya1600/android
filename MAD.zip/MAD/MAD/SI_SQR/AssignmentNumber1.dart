import 'dart:io';

 simpleint(){//(p*t*r)/100
   print("Enter the Principle:");
   num? p=num.parse(stdin.readLineSync()!);
   print("Enter the Time (in year):");
   num? t=num.parse(stdin.readLineSync()!);
   print("Enter the Rate:");
   num? r=num.parse(stdin.readLineSync()!);

  num SimpleInterest;

  SimpleInterest=(p*t*r)/100;
  print("Simple Interest is:$SimpleInterest");
}

void sqr(){
   print("Enter the number for square:");
   num? number=num.parse(stdin.readLineSync()!);
   num squre = number*number;
   print("Squre of $number is :$squre");
}
void FullName()
{
  print("Enter the First Name:");
  String? firstname=stdin.readLineSync();
  print("Enter the Middle Name:");
  String? middlename= stdin.readLineSync();
  print("Enter the Last Name:");
  String? lastname= stdin.readLineSync();
  print("First Name is: '$firstname' Middle Name is : '$middlename' Last Name is: '$lastname'");
}

void quotientremainder(){
   print("Enter Dividend:");
   int? divident=int.parse(stdin.readLineSync()!);
   print("Enter Divisor:");
   int? divisor = int.parse(stdin.readLineSync()!);
   num quotient = divident/divisor;
   num remainder = divident%divisor;
   print("Quotient is:$quotient");
   print("Remainder is:$remainder");
}

void swap() {
   print("Enter the two number:");
   int a = int.parse(stdin.readLineSync()!);
   int b = int.parse(stdin.readLineSync()!);
   int temp;
   print("Before swap : '$a' , '$b'");
  temp=a;
   a=b;
   b=temp;
   print("After swap: '$a' , '$b' ");
}

void splitebill(){
   print("Enter the Total Amount of bill:");
   num? bill=num.parse(stdin.readLineSync()!);
   print("Enter the Total number of person:");
   int person=int.parse(stdin.readLineSync()!);
   num formula = bill/person;
   print("Splite amount of bill:$formula");
}

void distanceandspeed(){
   int distance = 25;
   int speedhours = 40;
   int speedminut = speedhours*60;
   num formula = distance / speedminut;
   print("Time :$formula");
}
void stringtoint(){
   String? str;
   stdout.write("Enter string having number:");
   str=stdin.readLineSync()!;
   int num=int.parse(str);
   stdout.write("String in int:$num");

}

void whitespace(){
   print("\nEnter any string:");
   String? str = stdin.readLineSync()!;
   print(str.split(" ").join(""));
}

int main()
{
  print("Assignment Number 1.");
  const int number = 7;
  simpleint();//Q
  sqr();//Q
  FullName();//Q
  quotientremainder();//Q
  swap();//Q
  splitebill();//Q
  distanceandspeed();//Q
  stringtoint();//Q
  whitespace();//Q
  return 0;
}
