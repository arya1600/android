import 'package:contact_card/Contacts.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

    List<Contacts> Cont=[
      Contacts("Aditya", 7666898977),
      Contacts("Sham", 7666563977),
      Contacts("Ashish", 787654310),
      Contacts("Akash", 1234567890),
    ];


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
     home: Scaffold(
       appBar: AppBar(
         title: Text("Contact List"),
         backgroundColor: Colors.orangeAccent,
         shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.all(Radius.circular(20))
         ),
       ),
       body: ListView.builder(
       itemCount: Cont.length,
           itemBuilder: (context,index){
         Contacts C=Cont[index];
         return ListTile(
           leading: CircleAvatar(
             backgroundColor: Colors.orange,
             child: Text(C.Name[0]),
           ),
           title: Text(C.Name),
           subtitle: Text(C.Number.toString()),
           trailing: IconButton(
             onPressed: (){

             },
             icon: Icon(Icons.call),
           ),
         );
       }),

     ),
    );
  }
}
