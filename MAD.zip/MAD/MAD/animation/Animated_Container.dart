import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Animated Container',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  double _imageWidth = 200;
  double _imageHeight = 250;
  bool _isEnlarged = true;

  void _toggleSize() {
    setState(() {
      if(_isEnlarged){
        _imageHeight=400;
        _imageWidth=300;
        _isEnlarged=false;
      }
      else{
        _imageHeight=250;
        _imageWidth=200;
        _isEnlarged=true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Animated Container.'),
        backgroundColor: Colors.grey,
      ),
      body: Center(
        child: GestureDetector(
          onTap: _toggleSize,
          child: AnimatedContainer(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
            ),
            duration: const Duration(seconds: 1),
            width: _imageWidth,
            height: _imageHeight,
            child: Image.asset(
              'assets/images/img.jpg',
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
