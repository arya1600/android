import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.grey,
          title: const Text('News Feed',style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
        ),
        body:Container(
          child:ListView(
            children: <Widget>[
              Padding(padding: const EdgeInsets.all(10),
                child:Card(
                  elevation: 15,
                  color: Colors.black12,
                  shadowColor: Colors.black,
                  shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: <Widget>[
                      Padding(padding: const EdgeInsets.all(10),
                        child: Container(
                          height: 150,
                          width: 390,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.black12
                          ),

                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Image.asset('assets/images/bbc.jpg',
                              fit: BoxFit.fill,
                            ),
                          ),
                        )
                        ,),

                      const Padding(padding: EdgeInsets.only(right: 300),
                        child: Text('02/04/2024',style: TextStyle(fontSize: 10,)) ,
                      ),


                      Padding(padding: const EdgeInsets.only(left: 20,top: 10,bottom: 10,right: 10),
                          child:ExpandablePanel(
                            header: const Text('Mass shooting in Atlanta',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            collapsed:const Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium. Interdum moana',style: TextStyle(fontSize: 15),overflow: TextOverflow.ellipsis,softWrap: true,) ,
                            expanded: const Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium. Interdum moana,Lorem ipsum dolor sit amet, consectetur ad.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium'),

                          )
                      ),

                      Container(
                        child: const Row(
                          children: <Widget>[
                            Padding(padding: EdgeInsets.only(left: 70,top: 10,bottom: 10,right: 10),
                              child: Text('Share',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),

                            Padding(padding: EdgeInsets.only(left: 50,top: 10,bottom: 10,right: 10),
                              child: Text('Bookmark',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),

                            Padding(padding: EdgeInsets.only(left: 50,top: 10,bottom: 10,right: 10),
                              child: Text('Link',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),

              Padding(padding: const EdgeInsets.all(10),
                child:Card(
                  elevation: 15,
                  color: Colors.black12,
                  shadowColor: Colors.black,
                  shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: <Widget>[
                      Padding(padding: const EdgeInsets.all(10),
                        child: Container(
                          height: 150,
                          width: 390,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.black12
                          ),

                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Image.asset('assets/images/news18.avif',
                              fit: BoxFit.fill,
                            ),
                          ),
                        )
                        ,),

                      const Padding(padding: EdgeInsets.only(right: 300),
                        child: Text('01/04/2024',style: TextStyle(fontSize: 10,)) ,
                      ),


                      Padding(padding: const EdgeInsets.only(left: 20,top: 10,bottom: 10,right: 10),
                          child:ExpandablePanel(
                            header: const Text('India Election Polls live....',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            collapsed:const Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium. Interdum moana',style: TextStyle(fontSize: 15),overflow: TextOverflow.ellipsis,softWrap: true,) ,
                            expanded: const Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium. Interdum moana,Lorem ipsum dolor sit amet, consectetur ad.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet tortor pretium'),

                          )
                      ),

                      Container(
                        child: const Row(
                          children: <Widget>[
                            Padding(padding: EdgeInsets.only(left: 70,top: 10,bottom: 10,right: 10),
                              child: Text('Share',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),

                            Padding(padding: EdgeInsets.only(left: 50,top: 10,bottom: 10,right: 10),
                              child: Text('Bookmark',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),

                            Padding(padding: EdgeInsets.only(left: 50,top: 10,bottom: 10,right: 10),
                              child: Text('Link',style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold)) ,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),


            ],
          ),
        )
      ),
    );
  }
}

