import 'package:flutter/material.dart';
import 'package:untitled2/main4.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(home: Scrollexe());
  }
}

class Scrollexe extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),

        body: Center(
          child: SingleChildScrollView(
            child: Column(children: List.generate(10, (index) => Container(
              width: 200,
              height: 100,
              color: Colors.lightBlueAccent,
              margin: EdgeInsets.all(10),
              child:Center(
                child: Text('Item $index',
                style: TextStyle(
                  color: Colors.black,
                )
                ),
              ),
            ))),
          ),
        ));
  }
}
