import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});


  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _selectIndex=0;

  void onTapped(index){
    setState(() {
      _selectIndex=index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Bottom Navigation Bar Example"),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(kBottomNavigationBarHeight),
            child: BottomNavigationBar(
              items: [
                BottomNavigationBarItem(label: "Back",icon: Icon(Icons.arrow_back)),
                BottomNavigationBarItem(label:"Home",icon: Icon(Icons.home)),
                BottomNavigationBarItem(label: "Forward",icon: Icon(Icons.arrow_forward))
              ],
              currentIndex: _selectIndex,
              onTap:onTapped,

            ),

          )
        ),

        body: Center(
          child: Text("Selected index is $_selectIndex"),
        ),
      ),
    );
  }
}