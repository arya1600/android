import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _selectIndex=0;
  void onTapped(index){
    setState(() {
      _selectIndex=index;
    });
  }
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Bottom Navigation bar."),
        ),
        body:
        Column(
          children: [
            SizedBox(height: 725,
            child: Center(
              child: Text("Selected index is $_selectIndex"),
            ),),
            BottomNavigationBar(items: [
              BottomNavigationBarItem(label:"Back",icon: Icon(Icons.arrow_back)),
              BottomNavigationBarItem(label:"Home",icon: Icon(Icons.home)),
              BottomNavigationBarItem(label:"Back",icon: Icon(Icons.arrow_forward)),
            ],
              currentIndex: _selectIndex,
              onTap: onTapped,

            ),
          ],
        ),
      ),
    );
  }
}


