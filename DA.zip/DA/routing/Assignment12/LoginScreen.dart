import 'dart:ui';
import 'package:assignments/Assignment12/PageOne.dart';
import 'package:assignments/Assignment12/main.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // var nameController =TextEditingController();
  TextEditingController emailcontroller  = new TextEditingController();
  TextEditingController passwordcontroller = new TextEditingController();
  String email = '';
  String password = '';
  //const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login Page",style: TextStyle(fontSize: 25),),
        backgroundColor: Colors.orange,
      ),
      body:
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 100),
            child: Center(child: Container(
                width: 300,
                child: TextField(
                  controller: emailcontroller,
                  onChanged: (value){
                    setState((){
                      email = value;
                    });
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20)
                    ),
                    hintText: "Please Enter Your Email Id",
                    suffixIcon: Icon(Icons.email),
                  ),
                )
            )
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Container(
              width: 300,
              child: TextField(
                controller: passwordcontroller,
                onChanged: (value){
                  setState(() {
                    password = value;
                  });
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25)
                  ),
                  hintText: 'Please Enter Your Password',
                  suffixIcon: Icon(Icons.password),
                ),obscureText: true,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 30),
            child: Container(
              child:
              OutlinedButton(
                style: ButtonStyle(backgroundColor: MaterialStatePropertyAll(Colors.orange)),
                onPressed:(){
                  if(email.toString().isEmpty || password.toString().isEmpty){
                    showDialog(context: context, builder: (BuildContext context)
                    {
                      return
                        AlertDialog(
                          title: Text("Warning"),
                          // content: Text(""),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text('OK'),
                            )
                          ],
                        );
                    }
                  );
                  }
                  else{
                    Navigator.push(context,MaterialPageRoute(builder: (context)=>PageOne(emailcontroller.text.toString())));}
                  }, child: Text("Submit"),),
            ),
          )
        ],
      )
      ,
    );
  }
}