import 'package:assignments/Assignment12/RetriveData.dart';
import 'package:flutter/material.dart';
import 'package:assignments/Assignment12/LoginScreen.dart';
import 'package:assignments/Assignment12/main.dart';

class PageOne extends StatelessWidget {
  var name ;
  PageOne(this.name);
  //const PageOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: (Text("Page One")),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50.0),
              child: Container(
                child:
                Text("Hello $name",style: TextStyle(fontSize: 25),),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30.0),
              child: Container(
                child: OutlinedButton(onPressed:() {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>RetriveData()));
                },child: Text("Retrive Data")),
              ),
            )
          ],
        ),
      ),
    );
  }
}
