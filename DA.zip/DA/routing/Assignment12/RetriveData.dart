import 'package:assignments/Assignment12/LoginScreen.dart';
import 'package:flutter/material.dart';

class RetriveData extends StatefulWidget {
  const RetriveData({super.key});

  @override
  State<RetriveData> createState() => _RetriveDataState();
}

class _RetriveDataState extends State<RetriveData> {
  TextEditingController InputController = new TextEditingController();
  String textone = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      title: Text("Retrive Data",style: TextStyle(fontSize: 25),),
        backgroundColor: Colors.orange,
      ),
      body:
      Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 100),
            child: Center(child: Container(
                width: 300,
                child: TextField(
                  controller: InputController,
                  decoration:InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)
                    ),
                    hintText: "Please Enter Your Name",
                  ),
                )
              )
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Container(
              child: OutlinedButton(onPressed: (){
                setState(() {
                  textone = InputController.text;
                });
              }, child: Text("Submit",style: TextStyle(fontSize: 20),
              ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text("Hello $textone",style: TextStyle(fontSize: 20),),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 25.0),
            child: Container(
              child: OutlinedButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
              },child: Text("Login Page"),),
            ),
          )
        ],
      )
      ,
    );
  }
}
