import 'package:flutter/material.dart';

void main() {
  runApp(DialogApp());
}

class DialogApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dialog App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dialog App'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            _showDialog(context);
          },
          child: Text(
            'Show Dialog',
            style: TextStyle(fontSize: 20), // Set text font size
          ),
          style: ElevatedButton.styleFrom(
            minimumSize: Size(200, 50), // Set button size
          ),
        ),
      ),
    );
  }

  void _showDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Dialog Title',style: TextStyle(fontSize: 20),),
          content: Text('This is the dialog message.',style: TextStyle(fontSize: 20),),
          actions: <Widget>[
            TextButton(
              child: Text('OK',style: TextStyle(fontSize: 20),),
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
              },
            ),
          ],
        );
      },
    ).then((value) {
      // Return to the main screen after closing the dialog
      Navigator.pop(context);
    });
  }
}
