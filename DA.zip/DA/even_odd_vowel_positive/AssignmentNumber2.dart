import 'dart:io';
void evenodd(){
  print("Enter the number for check even or odd:");
  int? num = int.parse(stdin.readLineSync()!);
  if(num%2==0){
    print("This number is even and number is:$num");
  }else {
    print("This number is odd and number is:$num");
  }
}

void vowelconsonant(){
  int length;
  print("Enter the character:");
  String? char = stdin.readLineSync()!;
  length =char.length;
  if(length == 1) {
    switch (char) {
      case "a":
      case "A":
      case "e":
      case "E":
      case "i":
      case "I":
      case "o":
      case "O":
      case "u":
      case "U":
        print("This is the vowels:$char");
      default:
        print("This is the consonant:$char");
    }
  }else {
    print("You length is more then one character:");
  }
}
void checknumber(){
  print("Enter the number:");
  num? number = num.parse(stdin.readLineSync()!);
  if(number>0) print("Number is Positive:$number");
  else if(number<0) print("Number is Negetive:$number");
  else print("Number is zero.");
}

void nameprint(){
  print("Enter your name:");
  String? name = stdin.readLineSync();
  int i;
  for(i=1;i<=100;i++){
    print("$i $name");
  }
}

void naturalnumber(){
  print("Enter the any random number:");
  int? number= int.parse(stdin.readLineSync()!);
  int sum=0;
  for(int i=0;i<=number;i++){
    sum+=i;
  }
  print("Sum of $num natural number is : $sum ");
}

void table(){
  int temp=0;
  int tablenumber =5;
  print("Table of 5 is :");
  for(int i=1;i<=10;i++){
    temp=tablenumber*i;
    print("$temp");
  }
}

void calculator(){
  print("Enter two numbers :");
  num? number1 = num.parse(stdin.readLineSync()!);
  num? number2 = num.parse(stdin.readLineSync()!);
  print("Select the oparetor:(1.Addition 2)Subtraction 3)Multiplication 4)Division)");
  int? opretor = int.parse(stdin.readLineSync()!);
  num number3;
  switch(opretor){
    case 1:
      number3=number1+number2;
      print("Addition is:$number3");
      break;
    case 2:
      number3=number1-number2;
      print("Subtraction is:$number3");
      break;
    case 3:
      number3=number1*number2;
      print("Multiplication is:$number3");
      break;
    case 4:
      number3=number1/number2;
      print("Division is:$number3");
      break;
  }
}

void printnumber(){
  int i;
  for(i=1;i<=100;i++){
    if(i==41){}
    else {
      print("$i");
    }
  }
}

int main(){
  print("Assignment Number 2.");
  evenodd();//Q1
  vowelconsonant();//Q2
  checknumber();//Q3
  nameprint();//Q4
  naturalnumber();//Q5
  table();//Q6
  calculator();//Q7
  printnumber();//Q8
  return 0;
}