import 'package:flutter/material.dart';
import 'package:assignments/EButton.dart';
import 'package:assignments/outlinedButton.dart';
import 'package:assignments/IconButton.dart';
import 'package:assignments/Floating Action Button.dart';

class OutButton extends StatefulWidget {
  const OutButton({super.key});

  @override
  State<OutButton> createState() => _OutButtonState();
}

class _OutButtonState extends State<OutButton> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Outlined Buttom",style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.blueAccent),
      body:
      Center(
        child: ElevatedButton(
          onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>IButton()),);
            print("Go to the Outlined Button.");
          },
          child: Text("Click Button.",style: TextStyle(fontSize: 30),),
        ),
      ),
    );
  }
}
