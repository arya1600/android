import 'package:flutter/material.dart';
import 'package:assignments/EButton.dart';
import 'package:assignments/outlinedButton.dart';
import 'package:assignments/IconButton.dart';
import 'package:assignments/Floating Action Button.dart';
class EButton extends StatefulWidget {
  const EButton({super.key});

  @override
  State<EButton> createState() => _EButtonState();
}

class _EButtonState extends State<EButton> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Elevated Buttom",style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.blueAccent),
      body:
      Center(
        child: ElevatedButton(
          onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>OutButton()),);
            print("Go to the Outlined Button.");
          },
          child: Text("Click Button.",style: TextStyle(fontSize: 30)),
        ),
      ),
    );
  }
}
