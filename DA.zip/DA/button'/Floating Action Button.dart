import 'package:assignments/main.dart';
import 'package:flutter/material.dart';
import 'package:assignments/EButton.dart';
import 'package:assignments/outlinedButton.dart';
import 'package:assignments/IconButton.dart';
import 'package:assignments/Floating Action Button.dart';

class FAButton extends StatefulWidget {
  const FAButton({super.key});

  @override
  State<FAButton> createState() => _FAButtonState();
}

class _FAButtonState extends State<FAButton> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(
    title: Text("Floating Action Buttom",style: TextStyle(fontSize: 30)),
        backgroundColor: Colors.blueAccent),
        body:
        Center(
        child: ElevatedButton(
        onPressed: (){
          print("This is Floating Button.");
          Navigator.push(context,MaterialPageRoute(builder: (context)=>MyHomePage(title: "Home Page")));
          },
        child: Icon(Icons.add),
          ),
          ),
        );
  }
}
