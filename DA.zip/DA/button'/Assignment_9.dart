import 'package:assignments/main.dart';
import 'package:flutter/material.dart';
import 'package:assignments/EButton.dart';
import 'package:assignments/outlinedButton.dart';
import 'package:assignments/IconButton.dart';
import 'package:assignments/Floating Action Button.dart';

class Assignment9 extends StatefulWidget {
  const Assignment9({super.key});

  @override
  State<Assignment9> createState() => _Assignment9State();
}

class _Assignment9State extends State<Assignment9> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Text Button",style: TextStyle(fontSize: 30),),
        backgroundColor: Colors.blueAccent,
      ),
      body:
      Center(
      child: TextButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>EButton()),);
          print("Go to the Elevaed Button.");
        },
          child: Text("Click Button.",style: TextStyle(fontSize: 30),),
            ),
          ),
    );
  }
}
