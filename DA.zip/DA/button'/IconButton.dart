import 'package:flutter/material.dart';
import 'package:assignments/EButton.dart';
import 'package:assignments/outlinedButton.dart';
import 'package:assignments/IconButton.dart';
import 'package:assignments/Floating Action Button.dart';

class IButton extends StatefulWidget {
  const IButton({super.key});

  @override
  State<IButton> createState() => _IButtonState();
}

class _IButtonState extends State<IButton> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Icon Buttom",style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.blueAccent),
      body:
      Center(
        child: ElevatedButton(
          onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>FAButton()),);
            print("Go to the Outlined Button.");
          },
          child:Icon(Icons.add,),
        ),
      ),
    );
  }
}
