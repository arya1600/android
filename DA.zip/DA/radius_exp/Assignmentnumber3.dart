import 'dart:io';
import 'dart:math';

void areaofcircle(){
  print("Enter the radius:");
  num? r =num.parse(stdin.readLineSync()!);
  double pi = 3.14;
  num formula = pi*r*r;
  print("Area of Circul is : $formula");
}
void power(){
  print("Enter the Exponential number:");
  num? exponential=num.parse(stdin.readLineSync()!);
  num power= pow(5, exponential);
  print("Power is :$power");
}

num add(int a,int b){
  num sum=a+b;
  return sum;
}
int maxNumber(int i,int j,int k){
  if(i>j && i>k) return i;
  else if(j>i && j>k) return j;
  else return k;
}

bool isEven(int number){
  bool isEven;
  if(number%2==0) isEven=true;
  else isEven=false;
  return isEven;
}
void createUser(String name,int age,{required bool isActivity}){
  print("User details:");
  print("Name :$name");
  print("Age:$age");
  print("Active:${isActivity == true}");
}

num calculatArea(num length , num width){
  num area;
  area = length*width;
  return area;
}

void revercestring(){
  print("Enter the name:");
  int i;
  String str = "";
  String? name= stdin.readLineSync();
  for( i = (name!.length-1) ; i>=0 ; i--){
    str = str + name[i];
  }
  print("Reverce the name is:$str");

}

int main(){
  print("\nQue1:");
  areaofcircle();//Q1
  print("\nQue2:");
  revercestring();//Q2
  print("\nQue3:");
  power();//Q3
  print("\nQue4:");
  num sum=add(10,9);
   print("Addition is:$sum");//Q4
  print("\nQue5:");
  int maxnumber=maxNumber(12,15,23);
  print("Largest Number is:$maxnumber");//Q5
  print("\nQue6:");
  bool even=isEven(123);
  print("Number is:$even");//Q6
  print("\nQue7:");
  createUser("pranav",21 , isActivity : true);//Q7
  createUser("Pranav", 22,isActivity: true);
  num area=calculatArea(1,1);
  print("\nQue8:");
  print("Area of Rectangle is:$area");//Q8
  return 0;
}
