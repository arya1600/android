import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Kolhapur."),
        ),
        body: Center(
          child: Stack(
            children: [
              Container(
                height: 500,
                width: 400,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.orangeAccent
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                right: 10,
                child: Container(
                  decoration: BoxDecoration(borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
                    color: Colors.black54,),
                  padding: const EdgeInsets.all(10),
                  child: Text(
                    'Kolhapur is a city located in the southwestern region of Maharashtra, India.',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              Positioned(
                top: 80,
                left: 10,
                child: Container(
                  width: 190,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Image.asset('assets/images/kop-1.jpeg', fit: BoxFit.fill,),
                ),
              ),
              Positioned(
                top: 80,
                right: 10,
                child: Container(
                  width: 180,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Image.asset('assets/images/kop-2.jpeg', fit: BoxFit.fill),
                ),
              ),
              Positioned(
                top: 290,
                bottom: 10,
                left: 10,
                child: Container(
                  width: 380,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Image.asset('assets/images/kop-3.jpeg', fit: BoxFit.fill),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

