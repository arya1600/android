import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:Homepage() ,
    );
  }
}

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: Text("Panhala Tourism"),
            bottom: TabBar(tabs: [
              Tab(icon:Icon(Icons.photo)),
              Tab(icon:Icon(Icons.info)),
              Tab(icon:Icon(Icons.contact_page))
            ],
            ),
          ),

          body: TabBarView(
            children: [
                    Container(
                      decoration: BoxDecoration(color: Colors.orangeAccent),
                      child: Expanded(
                        child:
                            ListView(
                              scrollDirection: Axis.vertical,
                              children: [
                                Container(child: Image.asset('assets/images/images.jpeg',fit: BoxFit.fill,)),
                                Container(child: Image.asset('assets/images/images-2.jpeg',fit: BoxFit.fill,)),
                                Container(child: Image.asset('assets/images/images-3.jpeg',fit: BoxFit.fill,)),
                                Container(child: Image.asset('assets/images/images-3.jpeg',fit: BoxFit.fill)),
                                Container(child: Image.asset('assets/images/Unknown-1.jpeg',fit: BoxFit.fill)),
                                Container(child: Image.asset('assets/images/Unknown-2.jpeg',fit: BoxFit.fill)),
                                Container(child: Image.asset('assets/images/Unknown-3.jpeg',fit: BoxFit.fill))


                              ],
                            )


                      ),
                    ),
              Container(
                decoration: BoxDecoration(color: Colors.orange),
                child: Center(
                  child: Text("Panhala Fort is a significant historical fortification located in the Sahyadri Mountain Range in the Indian state of Maharashtra. Here's a brief overview of Panhala Fort sourced from WikipediaLocation: Panhala Fort is situated near the town of Panhala in the Kolhapur district of Maharashtra, India. It is approximately 20 kilometers northwest of Kolhapur city.History: Panhala Fort has a rich history dating back to ancient times. It was initially built around the 12th century and later expanded and fortified by various rulers, including the Shilahara dynasty, the Yadava dynasty, and the Bahamani Sultanate. The fort played a strategic role in the Deccan region due to its location atop a hill, providing commanding views of the surrounding landscape.Architecture: The fort features a blend of architectural styles influenced by various dynasties that ruled over it. It includes structures such as ramparts, bastions, gateways, temples, and reservoirs. The fortification is built using stone and includes intricate carvings and inscriptions.Significance: Panhala Fort holds historical and cultural significance as it has witnessed several important events throughout history, including battles and sieges. It was also the residence of the Maratha ruler Chhatrapati Shivaji Maharaj for a significant period.Tourism: Today, Panhala Fort is a popular tourist destination and a site of historical importance. Visitors can explore the fort complex, admire its architecture, and enjoy panoramic views of the surrounding landscape. The fort also hosts light and sound shows that depict its historical significance.Panhala Fort stands as a testament to the rich heritage and architectural prowess of ancient India, attracting history enthusiasts, tourists, and researchers alike.For more detailed information, you can visit the Wikipedia page dedicated to Panhala Fort: Panhala Fort - Wikipedia"),
                ),
              ),
              Container(
                decoration: BoxDecoration(color: Colors.deepOrange),
                child: ListView.builder(
                    itemCount: 1,
                    itemBuilder: (context,index){
                    return ListTile(
                      leading: CircleAvatar(child: Text("A"),),
                      title: Text("Aditya"),
                      subtitle: Text("7666898977"),
                      trailing: IconButton(onPressed:() {

                      },
                          icon:Icon(Icons.call)),
                    );
                }),
              )
          ],
          ),

        )
    );
  }
}
