import 'dart:io';

double add(double num1 ,double num2 ){
  return num1+num2;
}

void main(){
  double number1= 100;
  double number2=150;

  double sum= add(number1, number2);

  print('the sum is : $sum');
}