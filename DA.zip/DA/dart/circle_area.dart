import 'dart:io';
import 'dart:math';

double Circlearea(double radius){
  return pi *radius * radius;
}

void main(){
  double radius = 5.0;
  double area =Circlearea(radius);
  
  print('area of the circle is: $area');
}