import 'dart:io';

double maxno(double num1, double num2,double num3){
  double max= num1;
  if(num2 > max){
    max= num2;
  }
  if(num3>max){
    max=num3;
  }
  return max;
}

void main(){
  double number1= 20;
  double number2= 30;
  double number3= 99;

  double maximum=maxno(number1, number2, number3);
  
  print('the largest no is : $maximum');

}