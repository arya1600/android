import 'dart:io';

// Function to calculate power
int calculatePower(int base, int exponent) {
  int result = 1;

  for (int i = 0; i < exponent; i++) {
    result *= base;
  }

  return result;
}

void main() {
  // Take user input for the base and exponent
  stdout.write('Enter the base: ');
  int base = int.parse(stdin.readLineSync()!);

  stdout.write('Enter the exponent: ');
  int exponent = int.parse(stdin.readLineSync()!);

  // Call the function to calculate power
  int result = calculatePower(base, exponent);

  // Print the result
  print('$base^$exponent = $result');
}
