class User {
  String name;
  int age;
  bool isActive;

  User({required this.name, required this.age, this.isActive = true});
}

User createUser({required String name, required int age, bool isActive = true}) {
  return User(name: name, age: age, isActive: isActive);
}

void main() {
  User newUser1 = createUser(name: 'John ', age: 25);
  User newUser2 = createUser(name: 'Jane ', age: 30, isActive: false);

  print('User 1: ${newUser1.name}, Age: ${newUser1.age}, Active: ${newUser1.isActive}');
  print('User 2: ${newUser2.name}, Age: ${newUser2.age}, Active: ${newUser2.isActive}');
}
