double calculateArea({double length = 1, double width = 1}) {
  return length * width;
}

void main() {
  double area1 = calculateArea();
  double area2 = calculateArea(length: 5, width: 3);


  print('Area 1 (default values): $area1');
  print('Area 2 (length=5, width=3): $area2');
}
