import 'dart:io';

String reverseString(String input){
  List<String> characters= input.split('');
  characters=characters.reversed.toList();
  return characters.join();
}

void main(){
  print('enter a string');
  String userInput=stdin.readLineSync()!;

  String reversedString= reverseString(userInput);
  
  print('reversed string: $reversedString');
}