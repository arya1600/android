bool isEven(int number) {
  return number % 2 == 0;
}

void main() {
  int testNumber = 7;


  bool result = isEven(testNumber);

  print('Is $testNumber even? $result');
}
