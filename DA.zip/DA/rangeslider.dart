import 'package:flutter/material.dart';
import 'package:untitled2/switch.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RangeSlider(),
    );
  }
}

class RangeSlider extends StatefulWidget{
  RangeSliderexample createState() => RangeSliderexample();
}

class RangeSliderexample extends State{

  double start = 20.0;
  double end = 80.0;

  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Range Slider'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children:[
            Text(
              'Range:$start - $end',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            SizedBox(height: 20),
            RangeSliderExample(
              values:RangeValues(start,end),
              min:0.0,
              max:100,
              onChanged:(RangeValues values)
                {
                  setState(() {
                    start=values.start;
                    end=values.end;
                  });
                }
            )
          ],
        ),
      ),
    );
  }
}
