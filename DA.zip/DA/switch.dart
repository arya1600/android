import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RangeSliderExample(),
    );
  }
}

class RangeSliderExample extends StatefulWidget {
  @override
  _RangeSliderExampleState createState() => _RangeSliderExampleState();
}

class _RangeSliderExampleState extends State
{
  double _startValue = 20.0;
  double _endValue = 80.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Range Slider Example'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Range: $_startValue - $_endValue',
              style: TextStyle(fontSize: 20.0),
            ),
            SizedBox(height: 20.0),
            RangeSlider(
              values: RangeValues(_startValue, _endValue),
              min: 0.0,
              max: 100.0,
              onChanged: (RangeValues values) {
                setState(() {
                  _startValue = values.start;
                  _endValue = values.end;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
